<template>
    <div class="c-light" style="width: 100%; height: 100vh; margin:-8px; display: flex; justify-content: center; align-items: center;">
        <div style="width: 90%; margin-left: 5%; text-align: center; color: #10517d;">
            <p class="c-bold" style="font-size: 50px;">Oops..!</p>
            <p>Page you are looking for has been moved or do not exist.</p>
            <p class="c-light" style=" font-size: 15px; margin-left: 20px; color: #00c6fb;" onclick="window.location.href = '/'">Dashboard ↗︎</p>
        </div>
    </div>
</template>