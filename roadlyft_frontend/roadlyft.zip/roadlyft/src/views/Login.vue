<template>
    <div>
        <div class="c-bold" style="width: 100%; height: 50px; display: flex; align-items: center; position: fixed; background-color: white; margin: -8px;  z-index: 1"></div>
        <div class="c-bold" style="width: 100%; height: 50px; display: flex; align-items: center; position: fixed; background-color: white; margin: -8px; margin-top: 10px; z-index: 1">
            <img src="../components/icons/Roadlyft_LOGO.png" alt="" height="100%" width="auto" style="margin-left: 20px;">
            <p style="font-size: 30px; color: #10517d; margin-left: 10px; padding-top: 5px;">Roadlyft</p>

        </div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <div id="login-curr">

            <div class="c-light" style="width: 100%; display: flex; justify-content: center; ">
                <div style="width: 80%;">
                    <p style="font-size: 25px;">Log In...</p>
                </div>
            </div>
            <div style="width: 100%; display: flex; justify-content: center;">
                <div class="round-edge" style="background-color: transparent; height: 300px; box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);">
                <br>
                <div style="position: absolute; z-index:  -1; margin-left: 50px;">
                    <div style="height: 10px; width: 10px; border: 2px solid black; border-radius: 50px 50px 50px 50px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 7px; width: 7px; border: 2px solid black; margin-left: 2px;"></div>
                </div>
                <br>
                <p class="c-regular" style="position: absolute; margin-left: 80px; margin-top: 8px;">Mobile Number</p>
                <br>
                <div style="width: 100%; display: flex; justify-content: center; margin-top: -5px; ">
                    <div class="search" >
                        <!-- <svg width="25" height="25" viewBox="0 0 500 500" fill="none" xmlns="http://www.w3.org/2000/svg" style=" margin-top: 14px; margin-left: 11px; margin-right: 8px;">
                            <circle cx="200" cy="200" r="140" stroke="rgba(19, 19, 19, 0.423)" stroke-width="40"/>
                            <rect x="383.057" y="397.199" width="117.085" height="20" transform="rotate(-135 383.057 397.199)" fill="rgba(19, 19, 19, 0.423)" stroke="rgba(19, 19, 19, 0.423)" stroke-width="20" stroke-linejoin="round"/>
                        </svg> -->
                        <input id="mobile" class="search-inp c-regular" type="tel" placeholder="xxxxx - xxxxx" maxlength=10 min="10" style="margin-left: 20px;">
                    </div>
                </div>
                <br>
                <br>
                <p class="c-regular" style="position: absolute; margin-left: 80px; margin-top: 8px;">Password</p>
                <br>
                <div style="width: 100%; display: flex; justify-content: center; margin-top: -5px; ">
                    <div class="search">
                    <!-- <svg width="25" height="25" viewBox="0 0 500 500" fill="none" xmlns="http://www.w3.org/2000/svg" style=" margin-top: 14px; margin-left: 11px; margin-right: 8px;">
                        <circle cx="200" cy="200" r="140" stroke="rgba(19, 19, 19, 0.423)" stroke-width="40"/>
                        <rect x="383.057" y="397.199" width="117.085" height="20" transform="rotate(-135 383.057 397.199)" fill="rgba(19, 19, 19, 0.423)" stroke="rgba(19, 19, 19, 0.423)" stroke-width="20" stroke-linejoin="round"/>
                    </svg> -->
                    <input id="password" class="search-inp c-regular" type="password" placeholder="Password" style="margin-left: 20px;">
                    </div>
                </div>
                
                </div>
                
            </div>
            <br>
            <br>
            <div style="width: 100%; display: flex; justify-content: center;"> 
                  <div id="sub" class="round-edge" style="display: flex; justify-content: center; background-color: #00c6fb;"> 
                      <p id="sub_text" class="c-bold" style=" font-size: 20px; margin-top: 15px;">Login</p>
                  </div>
            </div>
            <br>
            <br>
            <div style="display: flex; justify-content: center; width: 100%;">
                  <div onclick="document.getElementById('login-curr').style.display = 'none';
                                document.getElementById('login-create').style.display = 'block';" 
                                class="round-edge">
                    <p class="c-light" style=" font-size: 15px; margin-left: 20px; ">Don't have account? Create here.</p>
                  </div>
            </div>
            <br>
            <br>
            <br>
        </div>
        <div id="login-create" style="display: none;">
            <div class="c-light" style="width: 100%; display: flex; justify-content: center; ">
                <div style="width: 80%;">
                    <p style="font-size: 25px;">Create account</p>
                </div>
            </div>
            <div style="width: 100%; display: flex; justify-content: center;">
                <div class="round-edge" style="background-color: transparent; height: 420px; box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);">
                <br>
                <div style="position: absolute; z-index:  -1; margin-left: 50px;">
                    <div style="height: 10px; width: 10px; border: 2px solid black; border-radius: 50px 50px 50px 50px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 7px; width: 10px; border-top: 2px solid black; border-bottom: 2px solid black; margin-left: 2px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 7px; width: 10px; border-top: 2px solid black; border-bottom: 2px solid black; margin-left: 2px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid transparent; margin-left: 6px;"></div>
                    <div style="height: 5px; width: 0px; border-left: 2px solid black; margin-left: 6px;"></div>
                    <div style="height: 7px; width: 7px; border: 2px solid black; margin-left: 2px;"></div>
                </div>
                <br>
                <p class="c-regular" style="position: absolute; margin-left: 80px; margin-top: 8px;">Your Name</p>
                <br>
                <div style="width: 100%; display: flex; justify-content: center; margin-top: -5px; ">
                    <div class="search" >
                    <!-- <svg width="25" height="25" viewBox="0 0 500 500" fill="none" xmlns="http://www.w3.org/2000/svg" style=" margin-top: 14px; margin-left: 11px; margin-right: 8px;">
                        <circle cx="200" cy="200" r="140" stroke="rgba(19, 19, 19, 0.423)" stroke-width="40"/>
                        <rect x="383.057" y="397.199" width="117.085" height="20" transform="rotate(-135 383.057 397.199)" fill="rgba(19, 19, 19, 0.423)" stroke="rgba(19, 19, 19, 0.423)" stroke-width="20" stroke-linejoin="round"/>
                    </svg> -->
                    <input id="name" class="search-inp c-regular" type="text" placeholder="Full Name"  style="margin-left: 20px;">
                    </div>
                </div>
                <br>
                <br>
                <p class="c-regular" style="position: absolute; margin-left: 80px; margin-top: 8px;">Mobile Number</p>
                <br>
                <div style="width: 100%; display: flex; justify-content: center; margin-top: -5px; ">
                    <div class="search" >
                    <!-- <svg width="25" height="25" viewBox="0 0 500 500" fill="none" xmlns="http://www.w3.org/2000/svg" style=" margin-top: 14px; margin-left: 11px; margin-right: 8px;">
                        <circle cx="200" cy="200" r="140" stroke="rgba(19, 19, 19, 0.423)" stroke-width="40"/>
                        <rect x="383.057" y="397.199" width="117.085" height="20" transform="rotate(-135 383.057 397.199)" fill="rgba(19, 19, 19, 0.423)" stroke="rgba(19, 19, 19, 0.423)" stroke-width="20" stroke-linejoin="round"/>
                    </svg> -->
                    <input id="n-mobile" class="search-inp c-regular" type="tel" placeholder="xxxxx - xxxxx" maxlength=10 min="10" style="margin-left: 20px;">
                    </div>
                </div>
                <br>
                <br>
                <p class="c-regular" style="position: absolute; margin-left: 80px; margin-top: 8px;">Password</p>
                <br>
                <div style="width: 100%; display: flex; justify-content: center; margin-top: -5px; ">
                    <div class="search">
                    <!-- <svg width="25" height="25" viewBox="0 0 500 500" fill="none" xmlns="http://www.w3.org/2000/svg" style=" margin-top: 14px; margin-left: 11px; margin-right: 8px;">
                        <circle cx="200" cy="200" r="140" stroke="rgba(19, 19, 19, 0.423)" stroke-width="40"/>
                        <rect x="383.057" y="397.199" width="117.085" height="20" transform="rotate(-135 383.057 397.199)" fill="rgba(19, 19, 19, 0.423)" stroke="rgba(19, 19, 19, 0.423)" stroke-width="20" stroke-linejoin="round"/>
                    </svg> -->
                    <input id="n-password" class="search-inp c-regular" type="password" placeholder="Password" style="margin-left: 20px;">
                    </div>
                </div>
                
                </div>
                
            </div>
            <br>
            <br>
            <div class="c-regular" style="width: 100%; display: flex; justify-content: center; ">
                <div style="width: 80%;">
                    <!-- <p style="font-size: 20px;">After completing your verificaiton process, Roadlyft will verify your documents and enable you to publish your ride.</p> -->
                    <p class="c-light" style="font-size: 15px;">By continuing, you agree the Terms and Conditions of Roadlyft.</p>
                </div>
            </div>
            <div style="width: 100%; display: flex; justify-content: center;"> 
                  <div id="create" class="round-edge" style="display: flex; justify-content: center; background-color: #00c6fb;"> 
                      <p id="create_text" class="c-bold" style=" font-size: 20px; margin-top: 15px;">Create</p>
                  </div>
            </div>
            <br>
            <br>
            <div style="display: flex; justify-content: center; width: 100%;">
                  <div onclick="document.getElementById('login-curr').style.display = 'block';
                                document.getElementById('login-create').style.display = 'none';"
                    class="round-edge">
                    <p class="c-light" style=" font-size: 15px; margin-left: 20px; ">Have account? Login here.</p>
                  </div>
            </div>
            <br>
            <br>
            <br>
        </div>
    </div>

</template>
<script>


const auth_toc_usr = getCookie('auth_toc_usr');
console.log("cookie: ", auth_toc_usr);
const loyalty = getCookie("lo_@_ty");
console.log("lo_@_ty:", loyalty);
const usr_verify = localStorage.getItem("dock-cid");
console.log("local_storage: ", usr_verify);
let booking_date_thresh = 0;

function getCookie(name) {
    const cookieString = document.cookie;
    const cookiesArray = cookieString.split('; ');
    for (let cookie of cookiesArray) {
        const [cookieName, cookieValue] = cookie.split('=');
        if (cookieName === name) {
            return cookieValue;
        }
    }
    return null; 
}


window.addEventListener('load', () => {
    function storeInLocalStorage(key, value) {
        try {
            // Convert the value to a string before storing
            const serializedValue = JSON.stringify(value);
            // Store the key-value pair in localStorage
            localStorage.setItem(key, serializedValue);
            console.log(`Stored "${key}" in localStorage.`);
        } catch (error) {
            // Handle errors, such as when localStorage is full
            console.error(`Error storing "${key}" in localStorage:`, error);
        }
    }

    function sub(){
        function setCookie(name, value, days) {
            let expires = "";
            if (days) {
                const date = new Date();
                date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
                expires = "; expires=" + date.toUTCString();
            }
            document.cookie = name + "=" + (value) + expires + "; path=/";
            console.log(`Cookie "${name}" set successfully.`);
        }
        var num = document.getElementById("mobile").value;
        let pass = document.getElementById("password").value;
        console.log(num.length);
        if (num.length > 9 && num.length < 11){
            document.getElementById("sub").removeEventListener("click", sub);
            document.getElementById("sub_text").innerText = "Loging...";

            if (pass.length > 3) {
                console.log("sending the request", num, pass);
                const mobile = document.getElementById('mobile').value;
                const password = document.getElementById('password').value;

                const data = {
                    mobile: mobile,
                    password: password
                };

                fetch('https://1ffe-103-234-240-164.ngrok-free.app/login', {
                    method: 'POST',
                    credentials: 'include',
                    
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Credentials': 'true',
                    },
                    body: JSON.stringify(data)
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    // Handle the response data
                    console.log('Response from server:', data);
                    if (data['LOGIN_STAT'] == "SUCCESS") {
                        storeInLocalStorage("dock-cid", data["dock-cid"]);
                        setCookie("auth_toc_usr", data["dock-cid"], 7);
                        window.location.replace("/");
                    }
                    else {
                        alert("Mobile or Password incorrect.");
                        document.getElementById("sub").addEventListener("click", sub);
                        document.getElementById("sub_text").innerText = "Login";
                    }
                })
                .catch(error => {
                    console.error('There was a problem with the fetch operation:', error);
                    alert("Something went wrong. Please try again after some time.");
                    document.getElementById("sub").addEventListener("click", sub);
                    document.getElementById("sub_text").innerText = "Login";
                });
                

            }
            else{
                alert("Incorrect password.");
            }
        }
        else {
            alert("Enter valid phone number");
        }
    }
    function create_acc(){
        function setCookie(name, value, days) {
            let expires = "";
            if (days) {
                const date = new Date();
                date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
                expires = "; expires=" + date.toUTCString();
            }
            document.cookie = name + "=" + (value) + expires + "; path=/";
            console.log(`Cookie "${name}" set successfully.`);
        }
        var num = document.getElementById("n-mobile").value;
        let pass = document.getElementById("n-password").value;
        let name = document.getElementById("name").value;
        
        if (name.length > 1){
        if (num.length > 9 && num.length < 11){
            document.getElementById("create").removeEventListener("click", create_acc);
            document.getElementById("create_text").innerText = "Creating...";

            if (pass.length > 3) {
                console.log("sending the request", num, pass);
                

                const data = {
                    user_name: name,
                    mobile: num,
                    password: pass
                };

                fetch('https://1ffe-103-234-240-164.ngrok-free.app/create_account', {
                    method: 'POST',
                    credentials: 'include',
                    
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Credentials': 'true',
                    },
                    body: JSON.stringify(data)
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    // Handle the response data
                    console.log('Response from server:', data);
                    if (data['ACC_C_STAT'] == "SUCCESS") {
                        storeInLocalStorage("dock-cid", data["dock-cid"]);
                        setCookie("auth_toc_usr", data["dock-cid"], 7);
                        window.location.replace("/");
                    }
                    else if (data['ACC_C_STAT'] == "DUPLICATE"){
                        alert("Account already exist, login insted.");
                        document.getElementById('login-curr').style.display = 'block';
                        document.getElementById('login-create').style.display = 'none';
                        document.getElementById("create").addEventListener("click", create_acc);
                        document.getElementById("create_text").innerText = "Create";
                    }
                    else {
                        alert("Mobile or Password incorrect.");
                        document.getElementById("create").addEventListener("click", create_acc);
                        document.getElementById("create_text").innerText = "Create";
                    }
                })
                .catch(error => {
                    console.error('There was a problem with the fetch operation:', error);
                    alert("Something went wrong. Please try again after some time.");
                    document.getElementById("create").addEventListener("click", create_acc);
                    document.getElementById("create_text").innerText = "Create";
                });
                

            }
            else{
                alert("Password length should be atleast 4");
            }
        }
        else {
            alert("Enter valid phone number");
        }
    }
    else{
        alert("Enter valid name");
    }
    }
    document.getElementById("sub").addEventListener("click", sub);
    document.getElementById("create").addEventListener("click", create_acc);

    var input = document.getElementById("password");
    input.addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        event.preventDefault();
        document.getElementById("sub").click();
    }
    });

    if (usr_verify == null){
        // window.location.replace("/login");
    }
    else if (auth_toc_usr == null){
        // window.location.replace("/login");
    }
    else if (auth_toc_usr != usr_verify.slice(1, -1)){
        console.log("malacious activity detected");
        // window.location.replace("/login");
    }
    else{
        window.location.replace("/");
    }
    
});

</script>